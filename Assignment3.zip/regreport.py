#!/usr/bin/env python3
"""This program reads from output file from Assignment3.py  and reports/prints 
on answers from answers.txt that is a csv file that has no header of column"""
import csv

answerfile = open("answers.csv")
csvreader = csv.reader(answerfile)
qfile = open("questions.csv")
#questions = qfile.read().splitlines()
#answers = answerfile.read().splitlines()
sessfile = open("sessions.csv")
answers = []
questions = []
sessions = []

qfile = open("questions.csv")
sessfile = open("sessions.csv")



def printsessions():
    count = 0
    for i in range(len(sortedsessions)):
        line = sortedsessions[i]
        n = i + 1
        name = line[0]
        if n != len(sortedsessions):
            nextline = sortedsessions[n]
        if count == 0:
            print("Registrant: \n", name)
            count = count+1
            #printsessions(name)

        print(f'\t\t{line[1]}')
        #printsessions(name)

        if str(line[0]) != str(nextline[0]):
            name = nextline[0]
            print("Registrant: \n", name)




def printquestions(number,answer):
    #print(number,answer)

    for x in sortedquestions:
        #print(x[3],answer)
        if x[0] == number:
            if x[3] == "False":
                print(f'\t\t {x[2]} is {answer}')

def search():
    count = 0
    for i in range(len(sortedanswers)):
        line = sortedanswers[i]
        n = i + 1
        name = line[0]
        if n != len(sortedanswers):
            nextline = sortedanswers[n]
        if count == 0:
            print("Registrant: \n", name)
            count = count+1
            #printsessions(name)

        printquestions(line[1], line[2])
        #printsessions(name)

        if str(line[0]) != str(nextline[0]):
            name = nextline[0]
            print("-"*80)
            print("Registrant: \n", name)


if __name__ == '__main__':

    # Sort questions and answers
    for row in csv.reader(qfile, delimiter=','):
        questions.append(row)

    sortedquestions = sorted(questions, key=lambda s: s[0])

    for row in csv.reader(sessfile, delimiter=','):
        sessions.append(row)
    print(sessions)
    sortedsessions = sorted(sessions, key=lambda s: s[0])

    #ortedquestions = sorted(questions, key=lambda s: s[1])

    for line in csv.reader(answerfile, delimiter=','):
        answers.append(line)

    sortedanswers = sorted(answers, key=lambda s: s[0])

    #print(sortedanswers)
    search()
    print("-"*40,"Sessions","-"*40)
    printsessions()
