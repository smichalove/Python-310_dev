#!/usr/bin/env python3
'''
Our app is now quite useful. We can manage and amend the questions easily. 
But now we need to be able to add features to save and load data. 
First we will deal with the questions.

Each question that we need to get answered will be stored in a file, 
and reloaded from the file when the program starts running.

We will build a new program to prompt for the questions, 
and store them in the file. Later, we will work on having the 
automated interviewer program read the questions from this file.

The file will store the question, a question id number that identifies 
the question throughout its life (creation to delete), 
a sequence number, indicating the order in which each question should
 be asked, and finally a flag that indicates if the questions is no 
longer to be used (a “deleted” flag which is True if the question 
is not to be used. For now that will default to False).

The file will look something like this:

questionid, sequencenumber, question,deletedflag

10,1,”What is your email”, False

Write the new program to capture the questions.

Now we will allow Automated Interviewer to load the questions from the question file so it 
can display and use them. Automated Interviewer must not assume the questions are in the 
correct sequence, so it needs to sort them before starting to use them. Run Automated Interviewer and make sure it works. Change the order of the questions, 
delete some and add some and check it all works as intended.

Finally we are going to modify Automated Interviewer to store the answers to the questions, and then write a new program print them.

The file will look something like this:

questionid,nameofpersoninterviewed,answer

2,”Andy”,”akmiles@uw.edu”

When the file is stored successfully create a new py file that 
will create a clearly formatted report that shows the name of the 
interviewee, and each question followed by its respective answers

       The report program is regreport.py'''
import csv

def listquestions():
    qfile=open("questions.csv")
    #questions = qfile.read().splitlines()
    questionslist= csv.reader(qfile)
    print(f"the questions are\n")
    for line in questionslist:
        print(line)
    qfile.close()

def sessions(ID): # register for classes
    qfile = open("sessions.txt")
    sessions = qfile.read().splitlines()
    #output sessions chosen to answers.txt
    answerfile = open("sessions.csv", "a")
    print("Select which of the following sessions you wish to attend – enter y or n:")
    choice = []
    for x in sessions:

        print(x)
        n=1
        inp=input()
        if inp.upper() == "Y":
            choice.append(ID)
            choice.append(x)
            csv_out = ",".join(choice)
            output = csv_out
            answerfile.writelines(output + "\n")
            print(f"you have chosen:{choice[1]}")
        choice.clear()
    output = csv_out
    answerfile.writelines(output + "\n")
    answerfile.close()
            


def whowhat(ID): #who are you and what conference
    import csv
    # Read questions from questions.txt and output input to answers.txt
    questions = []
    #listquestions()
    qfile = open("questions.csv")
    answerfile = open("answers.csv", "a")
    for row in csv.reader(qfile, delimiter=','):
        questions.append(row)
    sortedquestions = sorted(questions, key=lambda s: s[1])
    answer = []
    for x in sortedquestions:
        # add logic to omit delete questions
        if x[3] == "False":
            print (f'Question: {x[2]} ?')
            line = input()
            if x[2].find("Email") > 0:
                while line.find("@") == -1:
                    print("Invalid input for email!")
                    line = input()
            print(f'{x[2]} is:  { line}')
            answer.append(ID)
            answer.append(x[0])
            answer.append(line)
            csv_out = ",".join(answer)
            print(f"added {answer[2]}")
            output = csv_out
            answerfile.writelines(output + "\n")
            answer.clear()
    answerfile.close()



    




if __name__ == '__main__':

    print("running assigment3")
    done = "n"
    try:
        while True:
            StudentID = input("what is your name: ")
            whowhat(StudentID)
            sessions(StudentID)
            done = input("Are done, quit y/n?")
            if done.upper() == "Y":
                break

    except KeyboardInterrupt:   
        answerfile= open("answers.txt")
        answerfile.close()
        print("Thank you for registering!")

    finally:
        answerfile= open("answers.txt")
        answerfile.close()
        print("Thank you for registering!")