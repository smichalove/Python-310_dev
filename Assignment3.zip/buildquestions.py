## !/usr/bin/env python3
'''
We will build a new program to prompt for the questions, 
and store them in the file. Later, we will work on having the 
automated interviewer program read the questions from this file.

The file will store the question, a question id number that identifies 
the question throughout its life (creation to delete), 
a sequence number, indicating the order in which each question should
 be asked, and finally a flag that indicates if the questions is no 
longer to be used (a “deleted” flag which is True if the question 
is not to be used. For now that will default to False).

The file will look something like this:

questionid, sequencenumber, question,deletedflag

'''


import csv


def listquestions():
    qfile=open("questions.csv")
    questions = qfile.read().splitlines()
    print(f"the questions are\n")
    for line in questions:
        print(line)
    qfile.close()

def addquestions():
    print("add questions\n\n")
    qfile=open("questions.csv")
    questions= qfile.read().splitlines()  
    qfile.close()
    qfile=open("questions.csv","a")
    ID = str(len(questions))
    runagain = True
    while  runagain:
        delteflag=False
        answer=[]
        ID=int(ID)+1
        answer.append(str(ID))
        print("Enter Sequence Number: ")
        sequence = (input())
        try:
            int(sequence)
        except:
            print(f"{sequence} is not a Number")
            print("Enter Sequence Number: ")
            sequence = (input())

        answer.append(sequence)
        print("Enter Question to Ask : ")
        questionis = input()
        answer.append(questionis)
        answer.append(str(delteflag))
        print(answer)
        print("Add another question?  y/n: ")

        more  = input()
        if "Y" == more.upper():
            runagain = True
        else:
            runagain = False
        csv =  ",".join(answer)
        print(f"added {csv}")
        output=csv
        qfile.writelines(output + "\n")

    qfile.close()
    listquestions()   

def deletequestions():
    print("Do you want to delete questions (y/n):")
    willdelete = input()
    if "Y" == willdelete.upper():

        import csv
        import shutil
        f = open('questions.tmp', 'w',newline='\n')
        write = csv.writer(f)
        listquestions()
        qfile=open("questions.csv")
        delq = input()
        csvreader = csv.reader(qfile)
        #questions= qfile.read().splitlines()
        print("What question do you want to delete (number)? :")
        delq = input()
        csvreader = csv.reader(qfile)

        # Copy the old file to .tmp
        # delete a question then move .tmp to .csv

        for row in csvreader:
            #print(row)
            if row[1] == delq:
                row[3]="True"
                print (row)

            write.writerows([row])

        qfile.close()
        f.close()
        oldfile = r'questions.tmp'
        newfile = r'questions.csv'
        shutil.copyfile(oldfile,newfile)
    else:
        print("See you, bye!")
     

      
     
   
    




if __name__ == '__main__':
    listquestions()
    addquestions()
    deletequestions()

        
       

